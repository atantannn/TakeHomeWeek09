﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ANNEEEEEE_TH_09
{
    public partial class Form1 : Form
    {
        DataTable dtproduct = new DataTable();
        List<int> harga1 = new List<int>();
        List<int> harga2 = new List<int>();
        List<int> harga3 = new List<int>();
        public Form1()
        {
            InitializeComponent();
        }
        int nyimpen = 0;
        int subtotal = 0;
        int totalpajak = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = false;
            dtproduct.Columns.Add("Item Name");
            dtproduct.Columns.Add("Quantity");
            dtproduct.Columns.Add("Price");
            dtproduct.Columns.Add("Total");

            dgv_product.DataSource = dtproduct;
            txtbox_itemname.Enabled = false;
            txtbox_itemprice.Enabled = false;
            btn_add.Enabled = false;
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nyimpen = 0;

            panel1.Visible = true;
            pBox_item1.Image = Properties.Resources.Winnie_The_Pooh_Tshirt;
            lb_item1.Text = "Winnie the Pooh T-Shirt";
            pbox_item2.Image = Properties.Resources.Black;
            lb_item2.Text = "Black T-Shirt";
            pBox_item3.Image = Properties.Resources.Vneck_Tshirt;
            lb_item3.Text = "V-Neck T-Shirt";
            int price1 = 3000000;
            int price2 = 40000;
            int price3 = 100000;
            lb_harga1.Text = "Rp. " + price1.ToString("C").Remove(price1.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            lb_harga2.Text = "Rp. " + price2.ToString("C").Remove(price2.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            lb_harga3.Text = "Rp. " + price3.ToString("C").Remove(price3.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";

            harga1.Add(price1);
            harga2.Add(price2);
            harga3.Add(price3);
            panel2.Visible = false;
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nyimpen = 1;
            panel1.Visible = true;
            pBox_item1.Image = Properties.Resources.polo;
            lb_item1.Text = "Polo Shirt";
            pbox_item2.Image = Properties.Resources.plaid;
            lb_item2.Text = "Plaid Shirt";
            pBox_item3.Image = Properties.Resources.multistripe;
            lb_item3.Text = "Multistripe Shirt";
            int price1 = 170000;
            int price2 = 250000;
            int price3 = 400000;
            lb_harga1.Text = "Rp. " + price1.ToString("C").Remove(price1.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            lb_harga2.Text = "Rp. " + price2.ToString("C").Remove(price2.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            lb_harga3.Text = "Rp. " + price3.ToString("C").Remove(price3.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";

            harga1.Add(price1);
            harga2.Add(price2);
            harga3.Add(price3);
            panel2.Visible = false;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nyimpen = 2;
            panel1.Visible = true;
            pBox_item1.Image = Properties.Resources._short;
            lb_item1.Text = "Short Pants";
            pbox_item2.Image = Properties.Resources.cullote;
            lb_item2.Text = "Cullote Pants";
            pBox_item3.Image = Properties.Resources.jogger;
            lb_item3.Text = "Jogger Pant";

            int price1 = 50000;
            int price2 = 80000;
            int price3 = 1200000;

            lb_harga1.Text = "Rp. " + price1.ToString("C").Remove(price1.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            lb_harga2.Text = "Rp. " + price2.ToString("C").Remove(price2.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            lb_harga3.Text = "Rp. " + price3.ToString("C").Remove(price3.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";

            harga1.Add(price1);
            harga2.Add(price2);
            harga3.Add(price3);
            panel2.Visible = false;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nyimpen = 3;
            panel1.Visible = true;
            pBox_item1.Image = Properties.Resources._short;
            lb_item1.Text = "Short Pants";
            pbox_item2.Image = Properties.Resources.cullote;
            lb_item2.Text = "Cullote Pants";
            pBox_item3.Image = Properties.Resources.jogger;
            lb_item3.Text = "Jogger Pant";

            int price1 = 15000;
            int price2 = 85000;
            int price3 = 150000;

            lb_harga1.Text = "Rp. " + price1.ToString("C").Remove(price1.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            lb_harga2.Text = "Rp. " + price2.ToString("C").Remove(price2.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            lb_harga3.Text = "Rp. " + price3.ToString("C").Remove(price3.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";

            harga1.Add(price1);
            harga2.Add(price2);
            harga3.Add(price3);
            panel2.Visible = false;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nyimpen = 4;
            panel1.Visible = true;
            pBox_item1.Image = Properties.Resources.running;
            lb_item1.Text = "Running Shoes";
            pbox_item2.Image = Properties.Resources.badmin;
            lb_item2.Text = "Badminton Shoes";
            pBox_item3.Image = Properties.Resources.flatshoes;
            lb_item3.Text = "Flatshoes";
            int price1 = 780000;
            int price2 = 99000;
            int price3 = 6000000;

            lb_harga1.Text = "Rp. " + price1.ToString("C").Remove(price1.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            lb_harga2.Text = "Rp. " + price2.ToString("C").Remove(price2.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            lb_harga3.Text = "Rp. " + price3.ToString("C").Remove(price3.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";

            harga1.Add(price1);
            harga2.Add(price2);
            harga3.Add(price3);
            panel2.Visible = false;
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nyimpen = 5;
            panel1.Visible = true;
            pBox_item1.Image = Properties.Resources.necklace;
            lb_item1.Text = "Necklace";
            pbox_item2.Image = Properties.Resources.earings;
            lb_item2.Text = "Gold Earrings";
            pBox_item3.Image = Properties.Resources.ring;
            lb_item3.Text = "Cute Ring";

            int price1 = 100000;
            int price2 = 20000;
            int price3 = 200000;

            lb_harga1.Text = "Rp. " + price1.ToString("C").Remove(price1.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            lb_harga2.Text = "Rp. " + price2.ToString("C").Remove(price2.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            lb_harga3.Text = "Rp. " + price3.ToString("C").Remove(price3.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";

            harga1.Add(price1);
            harga2.Add(price2);
            harga3.Add(price3);
            panel2.Visible = false;
        }

        private void btn_item1_Click(object sender, EventArgs e)
        {
            bool cek = false;
            for (int i = 0; i < dtproduct.Rows.Count; i++)
            {
                if (dtproduct.Rows[i][0].ToString() == lb_item1.Text)
                {
                    cek = true;

                    int quantity = Convert.ToInt32(dtproduct.Rows[i][1].ToString());
                    quantity = quantity + 1;
                    dtproduct.Rows[i][1] = quantity.ToString();

                    if (nyimpen >= 0 && nyimpen < harga1.Count - 1)
                    {
                        int price = Convert.ToInt32(harga1[nyimpen].ToString());
                        price = quantity * price;
                        dtproduct.Rows[i][3] = "Rp. " + price.ToString("C").Remove(price.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";

                    }
                    break;
                }
            }

            if (cek == false)
            {
                dtproduct.Rows.Add(lb_item1.Text, 1, lb_harga1.Text, lb_harga1.Text);
            }
            if (nyimpen >= 0 && nyimpen< harga1.Count)
            {
                subtotal = subtotal + harga1[nyimpen];
                txtbox_subtotal.Text = "Rp" + subtotal.ToString("C").Remove(subtotal.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
                totalpajak = subtotal + (subtotal * 10 / 100);
                txtbox_total.Text = "Rp" + totalpajak.ToString("C").Remove(totalpajak.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            }
           
        }

        private void btn_item2_Click(object sender, EventArgs e)
        {
            bool cek = false;
            for (int i = 0; i < dtproduct.Rows.Count; i++)
            {
                if (dtproduct.Rows[i][0].ToString() == lb_item2.Text)
                {
                    cek = true;

                    int quantity = Convert.ToInt32(dtproduct.Rows[i][1].ToString());
                    quantity = quantity + 1;
                    dtproduct.Rows[i][1] = quantity.ToString();

                    if (nyimpen >= 0 && nyimpen < harga2.Count - 1)
                    {
                        int price = Convert.ToInt32(harga2[nyimpen].ToString());
                        price = quantity * price;
                        dtproduct.Rows[i][3] = "Rp. " + price.ToString("C").Remove(price.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
                    }
                    

                    break;
                }
            }

            if (cek == false)
            {
                dtproduct.Rows.Add(lb_item2.Text, 1, lb_harga2.Text, lb_harga2.Text);
            }
            if (nyimpen >= 0 && nyimpen < harga2.Count)
            {
                subtotal = subtotal + harga2[nyimpen];
                txtbox_subtotal.Text = "Rp" + subtotal.ToString("C").Remove(subtotal.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
                totalpajak = subtotal + (subtotal * 10 / 100);
                txtbox_total.Text = "Rp" + totalpajak.ToString("C").Remove(totalpajak.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            }

            
        }


        private void btn_item3_Click(object sender, EventArgs e)
        {
            bool cek = false;
            for (int i = 0; i < dtproduct.Rows.Count; i++)
            {
                if (dtproduct.Rows[i][0].ToString() == lb_item3.Text)
                {
                    cek = true;

                    int quantity = Convert.ToInt32(dtproduct.Rows[i][1].ToString());
                    quantity = quantity + 1;
                    dtproduct.Rows[i][1] = quantity.ToString();

                    if (nyimpen >=0 && nyimpen < harga3.Count - 1)
                    {
                        int price = Convert.ToInt32(harga3[nyimpen].ToString());
                        price = quantity * price;
                        dtproduct.Rows[i][3] = "Rp. " + price.ToString("C").Remove(price.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
                    }
                    
                    break;
                }
            }

            if (cek == false)
            {
                dtproduct.Rows.Add(lb_item3.Text, 1, lb_harga3.Text, lb_harga3.Text);
            }
            if (nyimpen >= 0 && nyimpen < harga3.Count)
            {
                subtotal = subtotal + harga3[nyimpen];
                txtbox_subtotal.Text = "Rp" + subtotal.ToString("C").Remove(subtotal.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
                totalpajak = subtotal + (subtotal * 10 / 100);
                txtbox_total.Text = "Rp" + totalpajak.ToString("C").Remove(totalpajak.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            }
            
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            panel1.Visible = false;
            panel2.Top = 30;
            panel2.Left = 100;
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            bool cek = false;
            int tbprice = Convert.ToInt32(txtbox_itemprice.Text);
            string har = "Rp. " + tbprice.ToString("C").Remove(tbprice.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            

            for (int i = 0; i < dtproduct.Rows.Count; i++)
            {
                if (dtproduct.Rows[i][0].ToString() == txtbox_itemname.Text && dtproduct.Rows[i][2].ToString() == har)
                {
                    cek = true;

                    int quantity = Convert.ToInt32(dtproduct.Rows[i][1].ToString());
                    quantity = quantity + 1;
                    dtproduct.Rows[i][1] = quantity.ToString();


                    int price = Convert.ToInt32(txtbox_itemprice.Text);
                    price = quantity * price;
                    dtproduct.Rows[i][3] = "Rp. " + price.ToString("C").Remove(price.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";

                    break;
                }
            }
            int priceadd = Convert.ToInt32(txtbox_itemprice.Text);
            txtbox_itemprice.Text = "Rp. " + priceadd.ToString("C").Remove(priceadd.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";

            if (cek == false)
            {
                dtproduct.Rows.Add(txtbox_itemname.Text, 1, txtbox_itemprice.Text, txtbox_itemprice.Text);
            }

            subtotal = subtotal + priceadd;
            txtbox_subtotal.Text = "Rp" + subtotal.ToString("C").Remove(subtotal.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            totalpajak = subtotal + (subtotal * 10 / 100);
            txtbox_total.Text = "Rp" + totalpajak.ToString("C").Remove(totalpajak.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            txtbox_itemprice.Clear();
            txtbox_itemname.Clear();


        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            txtbox_itemprice.Enabled = true;
            txtbox_itemname.Enabled = true;
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files(*.jpg, *.jpeg, *.png)|*.jpg; *.jpeg; *.png";

            ofd.ShowDialog();
            pictureBox1.Image = new Bitmap(ofd.FileName);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        bool bol = false;
        bool bol1 = false;
        private void txtbox_itemname_TextChanged(object sender, EventArgs e)
        {
            if (txtbox_itemname.Text == "")
            {
                bol = false;
            }
            else
            {
                bol = true;
            }

            if (bol == false)
            {
                btn_add.Enabled = false;
            }
            else if (bol == true && bol1 == true)
            {
                btn_add.Enabled = true;
            }
        }
       
        private void txtbox_itemprice_TextChanged(object sender, EventArgs e)
        {
            if (txtbox_itemprice.Text == "")
            {
                bol1 = false;
            }
            else
            {
                bol1 = true;
            }

            if (bol1 == false)
            {
                btn_add.Enabled = false;
            }
            else if (bol1 == true && bol == true)
            {
                btn_add.Enabled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dgv_product.SelectedCells.Count > 0)
            {
               foreach (DataGridViewCell cell in dgv_product.SelectedCells)
                {
                    if (cell.Selected)
                    {
                        dgv_product.Rows.RemoveAt(cell.RowIndex);
                    }
                }
            }
        }

        private void txtbox_itemprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
